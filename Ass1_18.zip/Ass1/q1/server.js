const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware to serve static files
app.use(express.static('public'));

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Handle GET request
app.get('/api/data', (req, res) => {
    res.json({ message: 'GET request received' });
});

// Handle POST request
app.post('/api/data', (req, res) => {
    const receivedData = req.body;
    res.json({ message: 'POST request received', data: receivedData });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
