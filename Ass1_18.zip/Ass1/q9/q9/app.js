const mysql = require('mysql2/promise');

const dbConfig = {
    host: 'localhost',
    user: 'yourUsername', 
    password: 'yourPassword', 
    database: 'company' 
};

async function connectDB() {
    const connection = await mysql.createConnection(dbConfig);
    console.log('Connected to the database.');
    return connection;
}

async function insertEmployee(connection, name, position, salary) {
    const query = 'INSERT INTO employee (name, position, salary) VALUES (?, ?, ?)';
    await connection.execute(query, [name, position, salary]);
    console.log('Employee record inserted.');
}


async function displayEmployees(connection) {
    const [rows] = await connection.execute('SELECT * FROM employee');
    console.log('Employee Records:');
    console.table(rows);
}


async function main() {
    const connection = await connectDB();
    
    try {
       
        await insertEmployee(connection, 'Bipasha Gosai', 'Developer', 60000);
        
        
        await displayEmployees(connection);
    } catch (error) {
        console.error('Error:', error);
    } finally {
        await connection.end();
        console.log('Connection closed.');
    }
}


main();
