// promisifiedUnlink.js

const fs = require('fs');
const util = require('util');

// Promisify the fs.unlink function
const unlink = util.promisify(fs.unlink);

// Function to delete a file
async function deleteFile(filePath) {
    try {
        await unlink(filePath);
        console.log(`File deleted: ${filePath}`);
    } catch (err) {
        console.error(`Error deleting file: ${err.message}`);
    }
}

// Example usage
const fileToDelete = 'test.txt'; // Change this to the file you want to delete

// Create a test file for demonstration
fs.writeFileSync(fileToDelete, 'This is a test file.');

deleteFile(fileToDelete);
