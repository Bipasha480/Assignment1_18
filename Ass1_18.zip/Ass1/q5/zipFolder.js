// zipFolder.js

const fs = require('fs-extra');
const archiver = require('archiver');

function zipFolder(sourceFolder, outPath) {
    const output = fs.createWriteStream(outPath);
    const archive = archiver('zip', {
        zlib: { level: 9 } // Set the compression level
    });

    output.on('close', () => {
        console.log(`ZIP file created: ${outPath} (${archive.pointer()} total bytes)`);
    });

    archive.on('error', (err) => {
        throw err;
    });

    archive.pipe(output);
    archive.directory(sourceFolder, false); // Include all files in the folder
    archive.finalize();
}

// Example usage
const folderToZip = 'example-folder'; // Change this to the folder you want to zip
const outputZipPath = 'output.zip'; // Name of the output zip file

zipFolder(folderToZip, outputZipPath);
