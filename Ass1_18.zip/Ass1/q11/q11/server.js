// server.js
const express = require('express');
const app = express();
const PORT = process.env.PORT || 8000;

// Set EJS as the templating engine
app.set('view engine', 'ejs');

// Serve static files
app.use(express.static('public'));

// Sample static cricket scores
const scores = [
    {
        series: { name: 'IPL 2023' },
        team1: { name: 'Team A' },
        team2: { name: 'Team B' },
        status: 'Team A: 100/5 (18.0 overs) - Team B: 155/2 (17.0 overs) - Team B won by 8 wickets'
    },
    {
        series: { name: 'ODI Series' },
        team1: { name: 'Team C' },
        team2: { name: 'Team D' },
        status: 'Team C: 198/10 (40.0 overs) - Team D: 201/3 (35.0 overs) - Team D won by 7 wickets'
    }
];

// Home route
app.get('/', (req, res) => {
    res.render('index');
});

// Scores route
app.get('/scores', (req, res) => {
    res.render('scores', { scores });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
